def hello():
    print("hello ganquan!")